package com.macro.mall.tiny.common.api;

/**
 * 封装API的错误码
 *
 * @Author: xwm93up
 * @Since: 2020/11/24 0:03
 * @Version: 1.0
 */
public interface IErrorCode {
    long getCode();

    String getMessage();
}
