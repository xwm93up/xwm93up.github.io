package com.macro.mall.tiny.service;

import com.macro.mall.tiny.common.api.CommonResult;

/**
 * 会员管理Service
 *
 * @Author: xwm93up
 * @Since: 2021/3/25 23:09
 * @Version: 1.0
 */
public interface UmsMemberSrevice {

    /**
     * 功能描述 : 生成验证码
     *
     * @Date 23:15 2021/3/25
     * @Param [telephone] 手机号码
     * @return com.macro.mall.tiny.common.api.CommonResult
     **/
    CommonResult generateAuthCode(String telephone);

    /**
     * 功能描述 : 判断验证码和手机号码是否匹配
     *
     * @Date 23:15 2021/3/25
     * @Param [telephone, authCode]
     * @return com.macro.mall.tiny.common.api.CommonResult
     **/
    CommonResult verifyAuthCode(String telephone, String authCode);
}
