package com.macro.mall.tiny.dao;

import com.macro.mall.tiny.mbg.model.UmsPermission;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * 后台管理与角色管理自定义dao
 *
 * @Author: xwm93up
 * @Since: 2021/4/7 21:28
 * @Version: 1.0
 */
public interface UmsAdminRoleRelationDao {

    /**
     * 功能描述 : 获取用乎所有权限
     *
     * @Date
     * @Param [adminId]
     * @return java.util.List<com.macro.mall.tiny.mbg.model.UmsPermission>
     **/
    List<UmsPermission> getPermissionList(@Param("adminId") Long adminId);
}
