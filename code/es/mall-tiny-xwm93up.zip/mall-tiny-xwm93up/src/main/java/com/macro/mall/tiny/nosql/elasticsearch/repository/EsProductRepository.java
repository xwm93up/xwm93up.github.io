package com.macro.mall.tiny.nosql.elasticsearch.repository;

import com.macro.mall.tiny.nosql.elasticsearch.document.EsProduct;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchCrudRepository;

/**
 * 商品ES操作类
 *
 * @Author: xwm93up
 * @Since: 2021/4/26 21:00
 * @Version: 1.0
 */
public interface EsProductRepository extends ElasticsearchCrudRepository<EsProduct, Long> {
    /**
     * 功能描述 : 搜索查询
     *
     * @Date
     * @Param name      商品名称
     * @Param subTitle  商品标题
     * @Param keywords  商品关键字
     * @Param page      分页信息
     * @return org.springframework.data.domain.Page<com.macro.mall.tiny.nosql.elasticsearch.document.EsProduct>
     **/
    Page<EsProduct> findByNameOrSubTitleOrKeywords(String name, String subTitle, String keywords, Pageable page);
}
