package com.macro.mall.tiny.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * 定时任务配置
 *
 * @Author: xwm93up
 * @Since: 2021/4/11 12:10
 * @Version: 1.0
 */
@Configuration
@EnableScheduling
public class SpringTaskConfig {

}
