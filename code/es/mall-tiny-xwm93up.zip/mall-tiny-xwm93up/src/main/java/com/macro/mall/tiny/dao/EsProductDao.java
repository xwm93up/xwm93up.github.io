package com.macro.mall.tiny.dao;

import com.macro.mall.tiny.nosql.elasticsearch.document.EsProduct;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * 搜索系统中的商品管理自定义Dao
 *
 * @Author: xwm93up
 * @Since: 2021/5/7 23:28
 * @Version: 1.0
 */
public interface EsProductDao {
    List<EsProduct> getAllEsProductList(@Param("id") Long id);
}
