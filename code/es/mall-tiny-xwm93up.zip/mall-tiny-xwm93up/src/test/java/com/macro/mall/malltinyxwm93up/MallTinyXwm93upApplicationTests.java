package com.macro.mall.malltinyxwm93up;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallTinyXwm93upApplicationTests {

    @Test
    void contextLoads() {
    }

}
